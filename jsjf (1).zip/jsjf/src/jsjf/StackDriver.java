/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsjf;

import java.util.Scanner;
import jsjf.exceptions.EmptyCollectionException;

/**
 *@author Stephen Zoyac
 * @Date: 9/27/20
 * Fall 2020
 * Linked Stack Project
 * This program runs a menu for a Linked Stack, which implements the StackADT
 *  The menu has 5 options, 1 to push an element on the stack, 2 to pop 
 * an element on the stack,  3 to see the element on top of the stack,
 * 4 to display all the elements of the stack, and 5 to close the program. 
 * If the stack is empty, and if the user tries to pop, peek, or display 
 * an empty stack, the exception will be caught, and the program will continue.
 */
public class StackDriver {

    public static void main(String args[]) throws CloneNotSupportedException {
        LinkedStack<String> lls = new LinkedStack<String>();
        Scanner input = new Scanner(System.in);

        int menu = 0;
        System.out.println("Stack Menu Selections 1.push | 2.pop |"
                + " 3.peek | 4.display | 5.Exit");
        System.out.println();
        do {

            System.out.print("Enter your choice: ");
            menu = Integer.parseInt(input.next());
            switch (menu) {
                case 1:
                    System.out.print("Enter element: ");
                    String element = input.next();
                    lls.push(element);

                    break;
                case 2:

                    System.out.println("Popped element is " + lls.pop());
                    break;
                case 3:

                    System.out.println("Current head is " + lls.peek());       
                    break;
                case 4:
                    lls.Display();
                    break;
                case 5:
                    System.exit(0);
            }
        } while (menu <= 5);

    }

}
